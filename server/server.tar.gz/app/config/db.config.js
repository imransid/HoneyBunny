const { createPool } = require("mysql");

const pool = createPool({
  host: "104.152.168.39",
  port: 22355,
  user: "honeybzj",
  password: "yttN7doAWU0h5",
  database: "honeybzj_honeybunnybd",
  connectionLimit: 10,
});

module.exports = pool;

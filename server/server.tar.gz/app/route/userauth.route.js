// const { createUser } = require("../controller/userauth.controller");

// const router = require("express").Router();

// router.post("/", createUser);

// module.exports = router;

module.exports = (app) => {
  const { createUser } = require("../controller/userauth.controller");

  var router = require("express").Router();

  // Create a new user
  router.post("/registration", createUser);

  //   // Retrieve all Tutorials
  //   router.get("/", tutorials.findAll);

  //   // Update a Tutorial with id
  //   router.put("/:id", tutorials.update);

  //   // Delete a Tutorial with id
  //   router.delete("/:id", tutorials.delete);

  //   // Create a new Tutorial
  //   router.delete("/", tutorials.deleteAll);

  app.use("/api/auth", router);
};

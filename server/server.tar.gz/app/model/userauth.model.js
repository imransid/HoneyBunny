const DB = require("../config/db.config");

module.exports = {
  create: (data, callback) => {
    DB.query(
      `insert into registration(firstname, lastname, gender, email, password, number) values(?,?,?,?,?,?)`,
      [
        data.firstname,
        data.lastname,
        data.gender,
        data.email,
        data.password,
        data.number,
      ],
      (error, result, fields) => {
        if (error) {
          return callback(error);
        }
        return callback(null, result);
      }
    );
  },
};
